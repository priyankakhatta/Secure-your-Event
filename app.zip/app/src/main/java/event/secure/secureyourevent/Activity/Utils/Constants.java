package event.secure.secureyourevent.Activity.Utils;

/**
 * Created by Priyanka on 11/2/2016.
 */
public class Constants {
    public class serviceType{

        private static final String WEB_URL = "http://androidmobiapps.com/donation/api/";
        // For App Login
        public static final String APP_LOGIN_URL = WEB_URL + "auth/login?";

        public static final String APP_FORGOT_PASSWORD = WEB_URL + "auth/forgotPassword?";

        public static final String APP_ANNOUNCEMENT_CAT = WEB_URL + "category/announcementCategories";

        public static final String APP_ANNOUNCEMENT_CAT_LIST = WEB_URL + "announcement/viewAll?";

        public static final String APP_MAIN_CAT_DONATION = WEB_URL + "product/donation?";

        public static final String APP_CAT_NEEDHELP= WEB_URL + "category/needhelpCategories?";

        public static final String APP_MAIN_CAT_WAREHOUSE= WEB_URL + "product/warehouse?";

        public static final String APP_NEEDHELP_CAT_LIST= WEB_URL + "/needhelp/viewAll?";

        public static final String APP_PRODUCT_QUERY= WEB_URL + "/product/enquiry?";

        public static final String APP_PRODUCT_READ_MORE= WEB_URL + "/product/viewProduct?";

        public static final String APP_SIGN_UP= WEB_URL + "/register/?";

        public static final String APP_COUNTRY = WEB_URL + "country";

        public static final String APP_REGION= WEB_URL + "product/getRegion?";

        public static final String APP_CITIES= WEB_URL + "product/getCities?";

        public static final String APP_TOP_SEARCH= WEB_URL + "product/topSearch?";

        public static final String APP_PRODUCT_CATEGORY_MAIN = WEB_URL + "category/mainCategories";

        public static final String APP_MY_PRODUCT = WEB_URL + "product/productList";

        public static final String APP_EDIT_PRODUCT = WEB_URL + "product/edit?";

        public static final String APP_MY_PRODUCT_DELETE = WEB_URL + "product/delete?id=";

    }

    public static String REGION = "";

    public static String CITY = "";

    public static String EDIT = "";
}
