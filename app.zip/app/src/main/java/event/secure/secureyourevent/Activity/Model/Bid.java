package event.secure.secureyourevent.Activity.Model;



public class Bid {


    private  String id;
    private String BUID;
    private String BEID;
    private String bidAmmount;
    private String eventName;
    private String like;
    private String comment;
    private String favourite;

    public Bid(String id, String BUID, String BEID, String bidAmmount, String eventName, String like, String comment, String favourite) {
        this.id = id;
        this.BUID = BUID;
        this.BEID = BEID;
        this.bidAmmount = bidAmmount;
        this.eventName = eventName;
        this.like = like;
        this.comment = comment;
        this.favourite = favourite;
    }



    public Bid(){

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getBUID() {
        return BUID;
    }

    public void setBUID(String BUID) {
        this.BUID = BUID;
    }

    public String getBEID() {
        return BEID;
    }

    public void setBEID(String BEID) {
        this.BEID = BEID;
    }

    public String getBidAmmount() {
        return bidAmmount;
    }

    public void setBidAmmount(String bidAmmount) {
        this.bidAmmount = bidAmmount;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public String getLike() {
        return like;
    }

    public void setLike(String like) {
        this.like = like;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getFavourite() {
        return favourite;
    }

    public void setFavourite(String favourite) {
        this.favourite = favourite;
    }



}
