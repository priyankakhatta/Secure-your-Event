package event.secure.secureyourevent.Activity.Model;

public class Profile {


    private String pid;
    private String uid;
    private String picUrl;
    private String fName;
    private String lName;
    private String phne;
    private String address;
    private String prefrence;
    private String aboutMe;


    public Profile(String pid,String uid, String picUrl, String fName, String lName, String phne, String address, String prefrence, String aboutMe) {
        this.pid = pid;
        this.uid = uid;
        this.picUrl = picUrl;
        this.fName = fName;
        this.lName = lName;
        this.phne = phne;
        this.address = address;
        this.prefrence = prefrence;
        this.aboutMe = aboutMe;
    }

    public Profile() {

    }


    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public String getPicUrl() {
        return picUrl;
    }

    public void setPicUrl(String picUrl) {
        this.picUrl = picUrl;
    }

    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public String getlName() {
        return lName;
    }

    public void setlName(String lName) {
        this.lName = lName;
    }

    public String getPhne() {
        return phne;
    }

    public void setPhne(String phne) {
        this.phne = phne;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPrefrence() {
        return prefrence;
    }

    public void setPrefrence(String prefrence) {
        this.prefrence = prefrence;
    }

    public String getAboutMe() {
        return aboutMe;
    }

    public void setAboutMe(String aboutMe) {
        this.aboutMe = aboutMe;
    }
}
