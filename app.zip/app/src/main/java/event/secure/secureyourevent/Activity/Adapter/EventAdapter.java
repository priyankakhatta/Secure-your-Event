package event.secure.secureyourevent.Activity.Adapter;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import event.secure.secureyourevent.Activity.Model.EventList;
import event.secure.secureyourevent.Activity.Model.Events;
import event.secure.secureyourevent.Activity.Utils.Constants;
import event.secure.secureyourevent.Activity.Utils.InternetConnectionDetector;
import event.secure.secureyourevent.Activity.Utils.My_Prefrence_Class;
import event.secure.secureyourevent.R;

public class EventAdapter extends BaseAdapter {

    private Context mContext;
    private ArrayList<Events> value;
    private int count = 0;
    private LayoutInflater inflater;
    private My_Prefrence_Class getPref;
    private InternetConnectionDetector cd;
    private Boolean isInternetPresent = false;
    private ProgressDialog pDialog;
    private String deleteID;


    public EventAdapter(Context context, ArrayList<Events> myProductLists){
        super();
        this.mContext = context;
        this.value = myProductLists;
    }


    @Override
    public int getCount() {
        return value.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }


    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        View itemView = convertView;
        ViewHolder holder = null;

        if (itemView == null)
        {
            final LayoutInflater layoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

            itemView = layoutInflater.inflate(R.layout.event_view_item_list, null); // parent, false

            holder = new ViewHolder();
            holder.eventNameFeed = (TextView)itemView.findViewById(R.id.eventNameFeed);
            holder.statusFeed = (TextView)itemView.findViewById(R.id.statusFeed);
            itemView.setTag(holder);

        } else {

            holder = (ViewHolder) itemView.getTag();
        }

        final Events item = value.get(position);


                    holder.eventNameFeed.setText(item.getEventTitleEditText());
            holder.statusFeed.setText(item.getPayEditText());



        return itemView;
    }

    static class ViewHolder
    {
        TextView eventNameFeed ;
        TextView statusFeed ;
    }

}
