package event.secure.secureyourevent.Activity.Utils;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Created by Priyanka on 10/26/2016.
 */
public class My_Prefrence_Class {


    SharedPreferences sp;


    // Shared pref file name
    private static final String PREF_NAME = "MyPref";
    // Context
    Context _context;
    // Shared pref mode
    int PRIVATE_MODE = 0;

    // Constructor
    public My_Prefrence_Class(Context context) {
        this._context = context;
        sp = _context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        // editor = sp.edit();
    }

    public void setActivate(boolean bool) {
        SharedPreferences.Editor editor = sp.edit();
        editor.putBoolean("isactivate", bool);
        editor.commit();

    }
 public void setlang(String lang)
 {
     SharedPreferences.Editor editor=sp.edit();
     editor.putString("lang",lang);
     editor.commit();
 }
    public String getlang()
    {
    return  sp.getString("lang","");
    }


    public boolean isActivate() {
        return sp.getBoolean("isactivate", false);
    }

}