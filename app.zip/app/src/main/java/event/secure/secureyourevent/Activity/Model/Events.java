package event.secure.secureyourevent.Activity.Model;

import java.io.Serializable;

public class Events implements Serializable {


    private String id;
    private String EUID;
    private String eventTitleEditText;
    private String dateEditText;
    private String eventPeriodEditText;
    private String uniformEditText;
    private String openEventTillEditText;
    private String jobDescriptionEditText;
    private String payEditText;
    private String numberOfGuardsEditText;
    private String addressOfEventEditText;
    private String instructionsEditText;


    public Events() {

    }


    public Events(String id, String EUID, String eventTitleEditText, String dateEditText, String eventPeriodEditText, String uniformEditText, String openEventTillEditText, String jobDescriptionEditText, String payEditText, String numberOfGuardsEditText, String addressOfEventEditText, String instructionsEditText) {

        this.id = id;
        this.EUID = EUID;
        this.eventTitleEditText = eventTitleEditText;
        this.dateEditText = dateEditText;
        this.eventPeriodEditText = eventPeriodEditText;
        this.uniformEditText = uniformEditText;
        this.openEventTillEditText = openEventTillEditText;
        this.jobDescriptionEditText = jobDescriptionEditText;
        this.payEditText = payEditText;
        this.numberOfGuardsEditText = numberOfGuardsEditText;
        this.addressOfEventEditText = addressOfEventEditText;
        this.instructionsEditText = instructionsEditText;
    }



    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getEUID() {
        return EUID;
    }

    public void setEUID(String EUID) {
        this.EUID = EUID;
    }

    public String getEventTitleEditText() {
        return eventTitleEditText;
    }

    public void setEventTitleEditText(String eventTitleEditText) {
        this.eventTitleEditText = eventTitleEditText;
    }

    public String getDateEditText() {
        return dateEditText;
    }

    public void setDateEditText(String dateEditText) {
        this.dateEditText = dateEditText;
    }

    public String getEventPeriodEditText() {
        return eventPeriodEditText;
    }

    public void setEventPeriodEditText(String eventPeriodEditText) {
        this.eventPeriodEditText = eventPeriodEditText;
    }

    public String getUniformEditText() {
        return uniformEditText;
    }

    public void setUniformEditText(String uniformEditText) {
        this.uniformEditText = uniformEditText;
    }

    public String getOpenEventTillEditText() {
        return openEventTillEditText;
    }

    public void setOpenEventTillEditText(String openEventTillEditText) {
        this.openEventTillEditText = openEventTillEditText;
    }

    public String getJobDescriptionEditText() {
        return jobDescriptionEditText;
    }

    public void setJobDescriptionEditText(String jobDescriptionEditText) {
        this.jobDescriptionEditText = jobDescriptionEditText;
    }

    public String getPayEditText() {
        return payEditText;
    }

    public void setPayEditText(String payEditText) {
        this.payEditText = payEditText;
    }

    public String getNumberOfGuardsEditText() {
        return numberOfGuardsEditText;
    }

    public void setNumberOfGuardsEditText(String numberOfGuardsEditText) {
        this.numberOfGuardsEditText = numberOfGuardsEditText;
    }

    public String getAddressOfEventEditText() {
        return addressOfEventEditText;
    }

    public void setAddressOfEventEditText(String addressOfEventEditText) {
        this.addressOfEventEditText = addressOfEventEditText;
    }

    public String getInstructionsEditText() {
        return instructionsEditText;
    }

    public void setInstructionsEditText(String instructionsEditText) {
        this.instructionsEditText = instructionsEditText;
    }


}
