package event.secure.secureyourevent.Activity.Model;

public class SecuityCompany {
}
