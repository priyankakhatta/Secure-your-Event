package event.secure.secureyourevent.Activity.Model;

public class Users {

    public String id;
    public String username;
    public String email;

        public Users() {
            // Default constructor required for calls to DataSnapshot.getValue(User.class)
        }

        public Users(String id, String username, String email) {
            this.username = username;
            this.email = email;
            this.id = id;

        }




    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }


}
