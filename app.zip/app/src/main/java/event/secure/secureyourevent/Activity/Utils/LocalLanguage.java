package event.secure.secureyourevent.Activity.Utils;

import android.content.Context;

import java.util.Locale;

/**
 * Created by Priyanka on 11/22/2016.
 */
public class LocalLanguage {

    public String whichLang="";



    public static Locale getLocale(Context mContext) {
        Locale mCurrent = mContext.getResources().getConfiguration().locale;
        return mCurrent;
    }
}
